
./HW2_echo hello world
./HW2_echo $HOME
./HW2_echo
./HW2_echo Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do \
 eiusmod tempor incididunt ut labore et dolore magna aliqua. Pharetra diam sit \
 amet nisl. Orci sagittis eu volutpat odio facilisis mauris. Bibendum enim \
 facilisis gravida neque.
